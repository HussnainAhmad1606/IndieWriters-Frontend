import React from 'react'
import AdminForm from '@/components/admin-form'
function page() {
  return (
    <div className='min-h-screen flex justify-center items-center'>
        <AdminForm/>
    </div>
  )
}

export default page