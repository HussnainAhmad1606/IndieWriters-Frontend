import MyEditor from '@/components/Editor'
import React from 'react'

function page() {
  return (
    
        
        <MyEditor/>
    
  )
}

export default page